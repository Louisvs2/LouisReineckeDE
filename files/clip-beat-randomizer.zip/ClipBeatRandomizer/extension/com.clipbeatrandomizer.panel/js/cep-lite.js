/*
 * cep-lite.js -- minimaler Ersatz fuer Adobes CSInterface.js.
 * Deckt genau das ab, was dieses Panel braucht: evalScript, Extension-Pfad,
 * Theme-Farbe und Datei-Dialog.
 */
var CEP = (function () {
    function host() {
        if (typeof window.__adobe_cep__ === 'undefined') return null;
        return window.__adobe_cep__;
    }

    function isHost() { return host() !== null; }

    function evalScript(script, callback) {
        var h = host();
        if (!h) {
            if (callback) callback('EvalScript error: kein CEP-Host (Panel ausserhalb von Premiere?)');
            return;
        }
        h.evalScript(script, callback || function () {});
    }

    function extensionPath() {
        var h = host();
        if (!h) return '';
        var p = h.getSystemPath('extension');
        p = decodeURI(p).replace(/^file:\/\//, '');
        // Windows: /C:/Users/... -> C:/Users/...
        if (/^\/[a-zA-Z]:/.test(p)) p = p.substring(1);
        return p;
    }

    function hostEnvironment() {
        var h = host();
        if (!h) return null;
        try { return JSON.parse(h.getHostEnvironment()); } catch (e) { return null; }
    }

    // Datei-Dialog ueber die CEP-Filesystem-API.
    function chooseFile(title, extensions, callback) {
        if (typeof window.cep === 'undefined' || !window.cep.fs) { callback(null); return; }
        var res = window.cep.fs.showOpenDialog(false, false, title || 'Datei waehlen', '', extensions || []);
        if (res && res.data && res.data.length) callback(res.data[0]);
        else callback(null);
    }

    // Als JS-String-Literal escapen, damit der Pfad heil im evalScript ankommt.
    function quote(str) {
        return JSON.stringify(String(str));
    }

    return {
        isHost: isHost,
        evalScript: evalScript,
        extensionPath: extensionPath,
        hostEnvironment: hostEnvironment,
        chooseFile: chooseFile,
        quote: quote
    };
})();
