/* main.js -- Panel-Logik: Optionen einsammeln, ExtendScript aufrufen, Ergebnis zeigen. */
(function () {
    'use strict';

    var STORAGE_KEY = 'clipBeatRandomizer.settings.v1';
    var FIELDS = ['beatsFile', 'bpm', 'bpmOffset', 'gridLength', 'pattern', 'firstBeat',
                  'maxCuts', 'startOffset', 'sourceTrack', 'sourceBin', 'targetTrack',
                  'seed', 'inPointMode'];
    var CHECKS = ['autoOffset', 'clearTarget', 'muteTargetAudio', 'avoidRepeat'];

    function $(id) { return document.getElementById(id); }
    function radio(name) {
        var els = document.getElementsByName(name);
        for (var i = 0; i < els.length; i++) { if (els[i].checked) return els[i].value; }
        return null;
    }
    function setRadio(name, value) {
        var els = document.getElementsByName(name);
        for (var i = 0; i < els.length; i++) { els[i].checked = (els[i].value === value); }
    }

    function status(msg, kind) {
        var el = $('status');
        el.textContent = msg;
        el.className = kind || '';
    }

    // -------------------------------------------------- Sichtbarkeit steuern

    function syncVisibility() {
        var src = radio('beatSource');
        var nodes = document.querySelectorAll('[data-when]');
        for (var i = 0; i < nodes.length; i++) {
            nodes[i].style.display = (nodes[i].getAttribute('data-when') === src) ? '' : 'none';
        }
        $('startOffset').disabled = $('autoOffset').checked || src === 'markers';
        $('autoOffset').disabled = (src === 'markers');

        var mode = radio('sourceMode');
        var srcNodes = document.querySelectorAll('[data-when-src]');
        for (var j = 0; j < srcNodes.length; j++) {
            srcNodes[j].style.display = (srcNodes[j].getAttribute('data-when-src') === mode) ? '' : 'none';
        }
    }

    // ------------------------------------------------------ Einstellungen

    function collect() {
        var o = {
            beatSource: radio('beatSource'),
            sourceMode: radio('sourceMode'),
            inPointMode: $('inPointMode').value
        };
        for (var i = 0; i < FIELDS.length; i++) {
            var f = FIELDS[i];
            if (f === 'inPointMode') continue;
            o[f] = $(f).value;
        }
        for (var j = 0; j < CHECKS.length; j++) o[CHECKS[j]] = $(CHECKS[j]).checked;

        // Zahlen als Zahlen schicken, damit ExtendScript nicht raten muss.
        var numeric = ['bpm', 'bpmOffset', 'gridLength', 'firstBeat', 'maxCuts',
                       'startOffset', 'sourceTrack', 'targetTrack', 'seed'];
        for (var k = 0; k < numeric.length; k++) {
            var n = parseFloat(o[numeric[k]]);
            o[numeric[k]] = isNaN(n) ? 0 : n;
        }
        return o;
    }

    function save() {
        try { window.localStorage.setItem(STORAGE_KEY, JSON.stringify(collect())); } catch (e) { /* egal */ }
    }

    function restore() {
        var raw;
        try { raw = window.localStorage.getItem(STORAGE_KEY); } catch (e) { return; }
        if (!raw) return;
        var o;
        try { o = JSON.parse(raw); } catch (e2) { return; }

        if (o.beatSource) setRadio('beatSource', o.beatSource);
        if (o.sourceMode) setRadio('sourceMode', o.sourceMode);
        if (o.inPointMode) $('inPointMode').value = o.inPointMode;
        for (var i = 0; i < FIELDS.length; i++) {
            var f = FIELDS[i];
            if (f === 'inPointMode' || o[f] === undefined) continue;
            $(f).value = o[f];
        }
        for (var j = 0; j < CHECKS.length; j++) {
            if (o[CHECKS[j]] !== undefined) $(CHECKS[j]).checked = !!o[CHECKS[j]];
        }
    }

    // ------------------------------------------------------------ Ausfuehren

    function jsxPath() {
        return CEP.extensionPath() + '/jsx/BeatRandomizer.jsx';
    }

    function loadJsx(callback) {
        // Bei jedem Lauf frisch laden: die ExtendScript-Engine wird von
        // Premiere gelegentlich zurueckgesetzt.
        var script = '$.global.BR_PANEL = true; $.evalFile(' + CEP.quote(jsxPath()) + '); "loaded";';
        CEP.evalScript(script, function (res) {
            callback(String(res).indexOf('loaded') >= 0, res);
        });
    }

    function describe(r) {
        var lines = [
            r.placed + ' CLIPS AUF DIE BEATS GESCHNITTEN',
            r.beats + ' Beats, Muster ' + r.pattern + ' \u2192 ' + r.cuts + ' Schnitte',
            r.sources + ' Quellclips \u00b7 ' + r.fps + ' fps \u00b7 Musik-Offset ' + r.offset + ' s',
            'L\u00e4nge ' + r.length + ' s, Ende bei ' + r.endTimecode
        ];
        if (r.shortSegments) lines.push('\u2014 ' + r.shortSegments + '\u00d7 war ein Clip k\u00fcrzer als sein Beat-Segment und wurde aufgef\u00fcllt.');
        if (r.failed) lines.push('\u2014 ' + r.failed + ' Platzierungen fehlgeschlagen.');
        if (r.mutedTracks) lines.push('\u2014 ' + r.mutedTracks + ' Audiospur(en) stumm geschaltet.');
        return lines.join('\n');
    }

    function run() {
        var btn = $('run');
        btn.disabled = true;
        status('SCHNEIDET \u2026');
        save();

        if (!CEP.isHost()) {
            status('Kein CEP-Host gefunden. Das Panel läuft nur innerhalb von Premiere Pro.', 'err');
            btn.disabled = false;
            return;
        }

        loadJsx(function (loaded, loadRes) {
            if (!loaded) {
                status('BeatRandomizer.jsx konnte nicht geladen werden.\n' + loadRes +
                       '\nErwartet unter: ' + jsxPath(), 'err');
                btn.disabled = false;
                return;
            }

            var arg = JSON.stringify(collect());
            var call = 'BeatRandomizer.runFromJSON(' + JSON.stringify(arg) + ');';
            CEP.evalScript(call, function (raw) {
                btn.disabled = false;
                var r;
                try { r = JSON.parse(raw); } catch (e) {
                    status('Unerwartete Antwort aus Premiere:\n' + raw, 'err');
                    return;
                }
                if (r.ok) status(describe(r), 'ok');
                else status('Fehler: ' + r.error + (r.log ? '\n' + r.log : ''), 'err');
            });
        });
    }

    // ------------------------------------------------------------- Startup

    function init() {
        restore();
        syncVisibility();

        var watch = document.querySelectorAll('input, select');
        for (var i = 0; i < watch.length; i++) {
            watch[i].addEventListener('change', function () { syncVisibility(); save(); });
        }

        $('browse').addEventListener('click', function () {
            CEP.chooseFile('beats.json wählen', ['json', 'txt'], function (path) {
                if (path) { $('beatsFile').value = path; save(); }
            });
        });

        $('reroll').addEventListener('click', function () {
            $('seed').value = Math.floor(Math.random() * 2000000000) + 1;
            save();
        });

        $('run').addEventListener('click', run);

        var env = CEP.hostEnvironment();
        $('version').textContent = env ? ('PPRO ' + env.appVersion) : 'OHNE HOST';
    }

    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init);
    else init();
})();
