/*
 * BeatRandomizerUI.jsx  --  Standalone-Dialog fuer BeatRandomizer.
 *
 * Diese Datei ausfuehren (VS Code ExtendScript Debugger -> Host "Adobe Premiere
 * Pro" -> "Evaluate Script in Host"), wenn man das CEP-Panel nicht benutzen will.
 *
 * Look: schwarz auf weiss, Orange nur als Akzent (louisreinecke.de).
 */

//@include "BeatRandomizer.jsx"

(function () {
    "use strict";

    var D = BeatRandomizer.DEFAULTS;

    // ── Farben (R,G,B,A je 0-1) ──────────────────────────────────────────────
    var C = {
        bg:     [1.000, 1.000, 1.000, 1],   // #FFFFFF
        orange: [1.000, 0.231, 0.000, 1],   // #FF3B00
        white:  [1.000, 1.000, 1.000, 1],   // #FFFFFF
        mid:    [0.541, 0.541, 0.541, 1],   // #8A8A8A
        black:  [0.000, 0.000, 0.000, 1]    // #000000
    };

    // ── Typografie (eine Familie: Systemschrift) ─────────────────────────────
    var F = {
        title:   ScriptUI.newFont("", ScriptUI.FontStyle.BOLD,    18),
        section: ScriptUI.newFont("", ScriptUI.FontStyle.BOLD,    11),
        label:   ScriptUI.newFont("", ScriptUI.FontStyle.REGULAR, 11),
        button:  ScriptUI.newFont("", ScriptUI.FontStyle.BOLD,    12),
        small:   ScriptUI.newFont("", ScriptUI.FontStyle.REGULAR, 10)
    };

    var LABEL_W = 150;

    // ── Farb-Helfer ──────────────────────────────────────────────────────────
    function bg(el, col) {
        el.graphics.backgroundColor =
            el.graphics.newBrush(el.graphics.BrushType.SOLID_COLOR, col);
    }
    function fg(el, col) {
        el.graphics.foregroundColor =
            el.graphics.newPen(el.graphics.PenType.SOLID_COLOR, col, 1);
    }
    function font(el, f) { el.graphics.font = f; }

    // ── Duenne Trennlinie (1 px) ─────────────────────────────────────────────
    function rule(parent, col) {
        var sep = parent.add("group");
        sep.alignment = ["fill", "top"];
        sep.preferredSize.height = 1;
        sep.onDraw = function () {
            var g = this.graphics, W = this.size[0];
            g.newPath(); g.rectPath(0, 0, W, 1);
            g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, col));
        };
        return sep;
    }

    function spacer(parent, h) {
        var p = parent.add("group");
        p.alignment = ["fill", "top"];
        p.preferredSize.height = h;
        bg(p, C.bg);
        return p;
    }

    // ── Karte (group, KEIN panel -> respektiert bg auf macOS) ────────────────
    function card(parent) {
        var c = parent.add("group");
        c.orientation   = "column";
        c.alignChildren = ["fill", "top"];
        c.alignment     = ["fill", "top"];
        c.spacing       = 6;
        c.margins       = [0, 4, 0, 4];
        bg(c, C.bg);
        return c;
    }

    // ── Abschnitts-Header ────────────────────────────────────────────────────
    function sectionTitle(parent, title) {
        var row = parent.add("group");
        row.orientation   = "row";
        row.alignChildren = ["left", "center"];
        row.alignment     = ["fill", "top"];
        row.margins       = [0, 0, 0, 6];
        bg(row, C.bg);

        var lbl = row.add("statictext", undefined, title);
        lbl.alignment = ["fill", "center"];
        font(lbl, F.section);
        fg(lbl, C.black);

        rule(parent, C.black);
        spacer(parent, 6);
    }

    // ── Beschriftete Zeile ───────────────────────────────────────────────────
    function row(parent, label) {
        var g = parent.add("group");
        g.orientation   = "row";
        g.alignChildren = ["left", "center"];
        g.alignment     = ["fill", "top"];
        g.spacing       = 12;
        g.margins       = [0, 2, 0, 2];
        bg(g, C.bg);

        var lbl = g.add("statictext", undefined, label);
        lbl.preferredSize.width = LABEL_W;
        lbl.alignment = ["left", "center"];
        font(lbl, F.label);
        fg(lbl, C.mid);
        return g;
    }

    // ── Hinweiszeile in Grau ─────────────────────────────────────────────────
    function hint(parent, text) {
        var g = parent.add("group");
        g.orientation = "row";
        g.alignment   = ["fill", "top"];
        g.margins     = [LABEL_W + 12, 0, 0, 2];
        bg(g, C.bg);
        var t = g.add("statictext", undefined, text);
        font(t, F.small);
        fg(t, C.mid);
        return t;
    }

    function text(parent, value, width) {
        var t = parent.add("edittext", undefined, String(value));
        t.preferredSize.width = width;
        font(t, F.label);
        return t;
    }

    function check(parent, label, value) {
        var c = parent.add("checkbox", undefined, label);
        c.value = !!value;
        font(c, F.label);
        fg(c, C.black);
        return c;
    }

    function radio(parent, label, value) {
        var r = parent.add("radiobutton", undefined, label);
        r.value = !!value;
        font(r, F.label);
        fg(r, C.black);
        return r;
    }

    // ── Fenster ──────────────────────────────────────────────────────────────
    var win = new Window("dialog", "Clip Beat Randomizer");
    win.orientation   = "column";
    win.alignChildren = ["fill", "top"];
    win.spacing       = 10;
    win.margins       = 16;
    bg(win, C.bg);

    // Kopf
    var hdr = win.add("group");
    hdr.orientation   = "row";
    hdr.alignChildren = ["left", "center"];
    hdr.alignment     = ["fill", "top"];
    hdr.margins       = [0, 0, 0, 6];
    bg(hdr, C.bg);

    var title = hdr.add("statictext", undefined, "CLIP BEAT RANDOMIZER");
    title.alignment = ["left", "center"];
    font(title, F.title);
    fg(title, C.black);

    var sub = hdr.add("statictext", undefined, "PREMIERE PRO");
    sub.alignment = ["right", "center"];
    font(sub, F.small);
    fg(sub, C.mid);

    rule(win, C.black);

    // ── 1 · Beats ────────────────────────────────────────────────────────────
    var c1 = card(win);
    sectionTitle(c1, "BEATS");

    var gQuelle = row(c1, "QUELLE");
    var rbJson   = radio(gQuelle, "beats.json", true);
    var rbMarker = radio(gQuelle, "Marker", false);
    var rbBpm    = radio(gQuelle, "BPM", false);

    var gFile = row(c1, "DATEI");
    var txtFile = text(gFile, D.beatsFile, 250);
    var btnBrowse = gFile.add("button", undefined, "Waehlen");
    btnBrowse.preferredSize.width = 70;
    btnBrowse.onClick = function () {
        var f = File.openDialog("beats.json waehlen");
        if (f) txtFile.text = f.fsName;
    };

    var gBpm = row(c1, "TEMPO");
    var txtBpm       = text(gBpm, D.bpm, 52);
    var stBpm        = gBpm.add("statictext", undefined, "BPM");
    var txtBpmOffset = text(gBpm, D.bpmOffset, 52);
    var stOff        = gBpm.add("statictext", undefined, "1. BEAT");
    var txtGridLen   = text(gBpm, D.gridLength, 52);
    var stLen        = gBpm.add("statictext", undefined, "LAENGE");
    var bpmUnits = [stBpm, stOff, stLen];
    for (var u = 0; u < bpmUnits.length; u++) { font(bpmUnits[u], F.small); fg(bpmUnits[u], C.mid); }

    var gOffset = row(c1, "MUSIK-OFFSET");
    var chkAutoOffset = check(gOffset, "Automatisch", D.autoOffset);
    var txtOffset = text(gOffset, D.startOffset, 52);
    var stSek = gOffset.add("statictext", undefined, "SEK.");
    font(stSek, F.small); fg(stSek, C.mid);

    var hintMarker = hint(c1, "Song abspielen und im Takt auf M tippen.");

    function syncBeatSource() {
        txtFile.enabled = btnBrowse.enabled = rbJson.value;
        txtBpm.enabled = txtBpmOffset.enabled = txtGridLen.enabled = rbBpm.value;
        chkAutoOffset.enabled = !rbMarker.value;
        txtOffset.enabled = !rbMarker.value && !chkAutoOffset.value;
        fg(hintMarker, rbMarker.value ? C.black : C.mid);
    }
    rbJson.onClick = rbMarker.onClick = rbBpm.onClick = syncBeatSource;
    chkAutoOffset.onClick = syncBeatSource;

    // ── 2 · Schnitt-Rhythmus ─────────────────────────────────────────────────
    var c2 = card(win);
    sectionTitle(c2, "SCHNITT-RHYTHMUS");

    var gPattern = row(c2, "BEATS/SCHNITT");
    var txtPattern = text(gPattern, D.pattern, 100);
    hint(c2, "1 = jeder Beat  ·  2 = jeder zweite  ·  4 = jeder Takt  ·  2,2,1,1 = Muster");

    var gFirst = row(c2, "AB BEAT NR.");
    var txtFirstBeat = text(gFirst, D.firstBeat, 52);
    var stMax = gFirst.add("statictext", undefined, "MAX. CUTS");
    font(stMax, F.small); fg(stMax, C.mid);
    var txtMaxCuts = text(gFirst, D.maxCuts, 52);
    var stAll = gFirst.add("statictext", undefined, "0 = ALLE");
    font(stAll, F.small); fg(stAll, C.mid);

    // ── 3 · Material ─────────────────────────────────────────────────────────
    var c3 = card(win);
    sectionTitle(c3, "MATERIAL");

    var gMode = row(c3, "CLIPS VON");
    var rbTrack = radio(gMode, "Videospur", true);
    var rbBin   = radio(gMode, "Bin", false);

    var gTrack = row(c3, "QUELLSPUR");
    var stV1 = gTrack.add("statictext", undefined, "V");
    font(stV1, F.small); fg(stV1, C.mid);
    var txtSourceTrack = text(gTrack, D.sourceTrack, 40);
    var stBin = gTrack.add("statictext", undefined, "BIN");
    font(stBin, F.small); fg(stBin, C.mid);
    var txtBin = text(gTrack, D.sourceBin, 170);

    var gTarget = row(c3, "ZIELSPUR");
    var stV2 = gTarget.add("statictext", undefined, "V");
    font(stV2, F.small); fg(stV2, C.mid);
    var txtTargetTrack = text(gTarget, D.targetTrack, 40);
    var chkClear = check(gTarget, "Vorher leeren", D.clearTarget);

    var gMute = row(c3, "CLIP-TON");
    var chkMute = check(gMute, "Audiospuren stumm schalten", D.muteTargetAudio);

    function syncSource() {
        txtSourceTrack.enabled = rbTrack.value;
        txtBin.enabled = rbBin.value;
    }
    rbTrack.onClick = rbBin.onClick = syncSource;

    // ── 4 · Zufall ───────────────────────────────────────────────────────────
    var c4 = card(win);
    sectionTitle(c4, "ZUFALL");

    var gIn = row(c4, "STARTPUNKT");
    var ddIn = gIn.add("dropdownlist", undefined,
                       ["Zufaellig im Clip", "Immer Clip-Anfang", "Fortlaufend"]);
    ddIn.selection = 0;
    ddIn.preferredSize.width = 180;
    font(ddIn, F.label);

    var gRepeat = row(c4, "REIHENFOLGE");
    var chkAvoid = check(gRepeat, "Keine direkte Wiederholung", D.avoidRepeat);

    var gSeed = row(c4, "SEED");
    var txtSeed = text(gSeed, D.seed, 80);
    var btnReroll = gSeed.add("button", undefined, "Neu wuerfeln");
    btnReroll.preferredSize.width = 100;
    btnReroll.onClick = function () {
        txtSeed.text = String(Math.floor(Math.random() * 2000000000) + 1);
    };
    var stSeed = gSeed.add("statictext", undefined, "0 = JEDES MAL NEU");
    font(stSeed, F.small); fg(stSeed, C.mid);

    // ── Aktion ───────────────────────────────────────────────────────────────
    spacer(win, 4);

    var btnRun = win.add("button", undefined, "");
    btnRun.alignment = ["fill", "top"];
    btnRun.preferredSize.height = 34;
    font(btnRun, F.button);
    btnRun.onDraw = function () {
        var g = this.graphics, W = this.size[0], H = this.size[1];
        g.newPath(); g.rectPath(0, 0, W, H);
        g.fillPath(g.newBrush(g.BrushType.SOLID_COLOR, C.orange));
        var txt = "AUF BEATS SCHNEIDEN";
        var pen = g.newPen(g.PenType.SOLID_COLOR, C.white, 1);
        var ms  = g.measureString(txt, g.font, W);
        g.drawString(txt, pen, (W - ms[0]) / 2, (H - ms[1]) / 2);
    };

    var gCancel = win.add("group");
    gCancel.alignment = ["fill", "top"];
    gCancel.alignChildren = ["right", "center"];
    bg(gCancel, C.bg);
    var btnCancel = gCancel.add("button", undefined, "Abbrechen", { name: "cancel" });
    btnCancel.preferredSize.width = 100;
    btnCancel.onClick = function () { win.close(0); };

    // ── Fuss ─────────────────────────────────────────────────────────────────
    rule(win, C.black);

    var foot = win.add("group");
    foot.orientation   = "row";
    foot.alignChildren = ["right", "center"];
    foot.alignment     = ["fill", "top"];
    foot.margins       = [0, 2, 0, 0];
    bg(foot, C.bg);
    var credit = foot.add("statictext", undefined, "BY LOUIS REINECKE");
    credit.alignment = ["right", "center"];
    font(credit, F.small);
    fg(credit, C.mid);

    // ── Ausfuehren ───────────────────────────────────────────────────────────
    btnRun.onClick = function () {
        var inModes = ["random", "start", "progressive"];
        var opts = {
            beatSource: rbMarker.value ? "markers" : (rbBpm.value ? "bpm" : "json"),
            beatsFile: txtFile.text,
            bpm: parseFloat(txtBpm.text),
            bpmOffset: parseFloat(txtBpmOffset.text),
            gridLength: parseFloat(txtGridLen.text),
            pattern: txtPattern.text,
            firstBeat: parseInt(txtFirstBeat.text, 10),
            maxCuts: parseInt(txtMaxCuts.text, 10),
            autoOffset: chkAutoOffset.value,
            startOffset: parseFloat(txtOffset.text),
            sourceMode: rbBin.value ? "bin" : "track",
            sourceTrack: parseInt(txtSourceTrack.text, 10),
            sourceBin: txtBin.text,
            targetTrack: parseInt(txtTargetTrack.text, 10),
            clearTarget: chkClear.value,
            muteTargetAudio: chkMute.value,
            inPointMode: inModes[ddIn.selection.index],
            avoidRepeat: chkAvoid.value,
            seed: parseInt(txtSeed.text, 10)
        };

        try {
            var res = BeatRandomizer.run(opts);
            win.close(1);
            alert(res.placed + " CLIPS AUF DIE BEATS GESCHNITTEN\n\n" +
                  res.beats + " Beats, Muster " + res.pattern + " → " + res.cuts + " Schnitte\n" +
                  res.sources + " Quellclips · " + res.fps + " fps · Musik-Offset " + res.offset + " s\n" +
                  "Länge " + res.length + " s, Ende bei " + res.endTimecode +
                  (res.shortSegments ? "\n— " + res.shortSegments + "× Clip kürzer als sein Segment, aufgefüllt." : "") +
                  (res.failed ? "\n— " + res.failed + " Platzierungen fehlgeschlagen." : ""),
                  "Clip Beat Randomizer");
        } catch (e) {
            alert("FEHLER\n\n" + e.toString(), "Clip Beat Randomizer");
        }
    };

    syncBeatSource();
    syncSource();

    win.center();
    win.show();
})();
