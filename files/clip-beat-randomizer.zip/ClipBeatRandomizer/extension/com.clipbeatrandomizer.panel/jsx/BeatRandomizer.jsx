/*
 * BeatRandomizer.jsx  --  Adobe Premiere Pro (ExtendScript / ES3)
 *
 * Schneidet vorbereitete Clips in zufaelliger Reihenfolge auf die Beats eines
 * Songs. Beat-Raster kommt entweder aus einer beats.json (tools/beat_detect.py),
 * aus Sequenz-Markern oder aus einer fest eingegebenen BPM-Zahl.
 *
 * Laeuft im mitgelieferten CEP-Panel oder standalone (VS Code ExtendScript
 * Debugger -> "Evaluate Script in Host"). Standalone oeffnet es einen Dialog.
 */

// eslint-disable-next-line no-unused-vars
var BeatRandomizer = (function () {
    var TICKS_PER_SECOND = 254016000000;
    var MEDIA_TYPE_ANY = 4;
    var MEDIA_TYPE_VIDEO = 1;

    var DEFAULTS = {
        beatSource: 'json',        // 'json' | 'markers' | 'bpm'
        beatsFile: '',
        bpm: 120,
        bpmOffset: 0,              // Sekunden bis zum ersten Beat
        gridLength: 180,           // Sekunden, nur fuer 'bpm'

        pattern: '1',              // Beats pro Schnitt, z.B. "1" oder "2,2,1,1"
        firstBeat: 0,              // Index des ersten genutzten Beats
        maxCuts: 0,                // 0 = unbegrenzt
        startOffset: 0,            // Musik-Offset in der Sequenz (Sekunden)
        autoOffset: true,          // Offset aus dem Musikclip lesen

        sourceMode: 'track',       // 'track' | 'bin'
        sourceTrack: 1,            // 1-basiert
        sourceBin: '',

        targetTrack: 2,            // 1-basiert
        clearTarget: true,
        muteTargetAudio: true,

        inPointMode: 'random',     // 'start' | 'random' | 'progressive'
        avoidRepeat: true,
        seed: 0,                   // 0 = echter Zufall
        minShotFrames: 2,
        bleedFrames: 1
    };

    // ---------------------------------------------------------------- utils

    var LOG = [];
    function log(msg) { LOG.push(String(msg)); }

    function has(o, k) { return o !== null && o !== undefined && o[k] !== undefined; }

    function pick(opts, key) {
        if (opts && has(opts, key) && opts[key] !== null && opts[key] !== '') return opts[key];
        return DEFAULTS[key];
    }

    function trim(s) { return String(s).replace(/^\s+|\s+$/g, ''); }

    function indexOf(arr, v) {
        for (var i = 0; i < arr.length; i++) { if (arr[i] === v) return i; }
        return -1;
    }

    function readTextFile(path) {
        var f = new File(path);
        if (!f.exists) throw new Error('Datei nicht gefunden: ' + path);
        f.encoding = 'UTF-8';
        if (!f.open('r')) throw new Error('Datei kann nicht gelesen werden: ' + path);
        var content = f.read();
        f.close();
        return content;
    }

    // ExtendScript hat kein natives JSON. eval() erst nach Struktur-Check
    // (Crockford-Test: nur JSON-Tokens duerfen uebrig bleiben).
    function parseJSON(str) {
        var s = trim(str);
        var probe = s.replace(/\\(?:["\\\/bfnrt]|u[0-9a-fA-F]{4})/g, '@')
                     .replace(/"[^"\\\n\r]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?/g, ']')
                     .replace(/(?:^|:|,)(?:\s*\[)+/g, '');
        if (!/^[\],:{}\s]*$/.test(probe)) throw new Error('Ungueltiges JSON (beats.json bzw. Optionen).');
        return eval('(' + s + ')');
    }

    function jsonEscape(s) {
        return String(s).replace(/\\/g, '\\\\').replace(/"/g, '\\"')
                        .replace(/\r/g, '\\r').replace(/\n/g, '\\n').replace(/\t/g, '\\t');
    }

    function basename(p) {
        var s = String(p).replace(/\\/g, '/');
        var i = s.lastIndexOf('/');
        return i < 0 ? s : s.substring(i + 1);
    }

    function stripExt(p) { return String(p).replace(/\.[^.\/\\]+$/, ''); }

    function round2(n) { return Math.round(n * 100) / 100; }

    function timecode(sec, fps) {
        var f = Math.round(sec * fps);
        var s = Math.floor(f / fps);
        var frames = f - s * fps;
        var m = Math.floor(s / 60);
        var h = Math.floor(m / 60);
        function p(n) { return (n < 10 ? '0' : '') + n; }
        return p(h) + ':' + p(m % 60) + ':' + p(s % 60) + ':' + p(Math.round(frames));
    }

    // Seedbarer Zufall (LCG) -- gleicher Seed = gleicher Edit.
    function makeRandom(seed) {
        var state = Math.floor(seed) || Math.floor(new Date().getTime() % 2147483647);
        if (state <= 0) state += 2147483646;
        return function () {
            state = (state * 16807) % 2147483647;
            return (state - 1) / 2147483646;
        };
    }

    // ------------------------------------------------------------ sequence

    function getSequence() {
        if (!app.project) throw new Error('Kein Projekt geoeffnet.');
        var seq = app.project.activeSequence;
        if (!seq) throw new Error('Keine aktive Sequenz. Bitte eine Sequenz oeffnen und anklicken.');
        return seq;
    }

    function getFps(seq) {
        var fps = 25;
        try {
            var tb = parseFloat(seq.timebase);
            if (tb > 0) fps = TICKS_PER_SECOND / tb;
        } catch (e) { /* fallback */ }
        if (!fps || fps < 1) fps = 25;
        return fps;
    }

    function snap(sec, fps) { return Math.round(sec * fps) / fps; }

    function toTime(sec) {
        var t = new Time();
        t.seconds = sec;
        return t;
    }

    function getVideoTrack(seq, oneBasedIndex, label) {
        var idx = Math.floor(oneBasedIndex) - 1;
        if (idx < 0 || idx >= seq.videoTracks.numTracks) {
            throw new Error(label + ' V' + oneBasedIndex + ' existiert nicht (Sequenz hat ' +
                            seq.videoTracks.numTracks + ' Videospuren).');
        }
        return seq.videoTracks[idx];
    }

    // ---------------------------------------------------------- beat grid

    function beatsFromFile(path) {
        var data = parseJSON(readTextFile(path));
        var raw = null;
        if (data instanceof Array) raw = data;
        else if (data && data.beats) raw = data.beats;
        if (!raw || !raw.length) throw new Error('Keine Beats in ' + basename(path) + ' gefunden.');

        var beats = [];
        for (var i = 0; i < raw.length; i++) {
            var v = raw[i];
            if (v !== null && v !== undefined && !isNaN(parseFloat(v))) beats.push(parseFloat(v));
        }
        beats.sort(function (a, b) { return a - b; });
        return { beats: beats, meta: data && data.beats ? data : {} };
    }

    function beatsFromMarkers(seq) {
        var beats = [];
        var markers = seq.markers;
        if (!markers || !markers.numMarkers) {
            throw new Error('Die Sequenz hat keine Marker. Song abspielen und mit M auf die Beats tippen.');
        }
        var m = markers.getFirstMarker();
        while (m) {
            beats.push(m.start.seconds);
            m = markers.getNextMarker(m);
        }
        beats.sort(function (a, b) { return a - b; });
        return { beats: beats, meta: { markerBased: true } };
    }

    function beatsFromBpm(bpm, offset, length) {
        if (!(bpm > 0)) throw new Error('BPM muss groesser als 0 sein.');
        var step = 60 / bpm;
        var beats = [];
        for (var t = offset; t <= offset + length; t += step) beats.push(t);
        return { beats: beats, meta: { bpm: bpm } };
    }

    function parsePattern(str) {
        var parts = String(str).split(/[,;\s]+/);
        var out = [];
        for (var i = 0; i < parts.length; i++) {
            var n = parseInt(trim(parts[i]), 10);
            if (n > 0) out.push(n);
        }
        if (!out.length) out.push(1);
        return out;
    }

    // Beats -> Schnittpunkte nach Muster (z.B. [2,2,1,1] = zwei lange, zwei kurze).
    function buildCutPoints(beats, pattern, firstBeat, maxCuts) {
        var cuts = [];
        var i = Math.max(0, Math.floor(firstBeat));
        var k = 0;
        while (i < beats.length) {
            cuts.push(beats[i]);
            if (maxCuts > 0 && cuts.length > maxCuts) break;
            i += pattern[k % pattern.length];
            k++;
        }
        return cuts;
    }

    // ------------------------------------------------------------- sources

    function sourcesFromTrack(seq, trackIndex) {
        var track = getVideoTrack(seq, trackIndex, 'Quellspur');
        var list = [];
        for (var i = 0; i < track.clips.numItems; i++) {
            var ti = track.clips[i];
            var pi = null;
            try { pi = ti.projectItem; } catch (e) { pi = null; }
            if (!pi) continue;

            var srcIn = 0, srcOut = 0;
            try { srcIn = ti.inPoint.seconds; srcOut = ti.outPoint.seconds; } catch (e2) { continue; }
            if (!(srcOut > srcIn)) continue;

            list.push({ name: ti.name, projectItem: pi, srcIn: srcIn, srcOut: srcOut, pos: srcIn });
        }
        if (!list.length) throw new Error('Auf V' + trackIndex + ' liegen keine nutzbaren Clips.');
        return list;
    }

    function findBin(item, name, depth) {
        if (depth > 12) return null;
        for (var i = 0; i < item.children.numItems; i++) {
            var child = item.children[i];
            if (child.type === ProjectItemType.BIN) {
                if (String(child.name).toLowerCase() === String(name).toLowerCase()) return child;
                var deeper = findBin(child, name, depth + 1);
                if (deeper) return deeper;
            }
        }
        return null;
    }

    function sourcesFromBin(binName) {
        var bin = findBin(app.project.rootItem, binName, 0);
        if (!bin) throw new Error('Bin "' + binName + '" nicht gefunden.');

        var list = [];
        for (var i = 0; i < bin.children.numItems; i++) {
            var pi = bin.children[i];
            if (pi.type === ProjectItemType.BIN) continue;
            var srcIn = 0, srcOut = 0;
            try {
                srcIn = pi.getInPoint(MEDIA_TYPE_ANY).seconds;
                srcOut = pi.getOutPoint(MEDIA_TYPE_ANY).seconds;
            } catch (e) { continue; }
            if (!(srcOut > srcIn)) continue;
            list.push({ name: pi.name, projectItem: pi, srcIn: srcIn, srcOut: srcOut, pos: srcIn });
        }
        if (!list.length) throw new Error('Bin "' + binName + '" enthaelt keine nutzbaren Clips.');
        return list;
    }

    // Musik-Offset: wo faengt der Song in der Sequenz an? Namenstreffer schlaegt
    // alles, sonst gilt der laengste Audioclip als der Song.
    function detectMusicOffset(seq, hintName) {
        var best = null, bestLen = -1;
        for (var t = 0; t < seq.audioTracks.numTracks; t++) {
            var track = seq.audioTracks[t];
            for (var i = 0; i < track.clips.numItems; i++) {
                var ti = track.clips[i];
                var offset = ti.start.seconds - ti.inPoint.seconds;
                var len = ti.end.seconds - ti.start.seconds;
                if (hintName && String(ti.name).toLowerCase().indexOf(String(hintName).toLowerCase()) >= 0) {
                    return offset;
                }
                if (len > bestLen) { bestLen = len; best = offset; }
            }
        }
        return best === null ? 0 : best;
    }

    // ------------------------------------------------------- shuffle & plan

    function makeBag(count, rnd, avoidRepeat) {
        var pool = [];
        var last = -1;

        function refill() {
            pool = [];
            for (var i = 0; i < count; i++) pool.push(i);
            for (var j = pool.length - 1; j > 0; j--) {   // Fisher-Yates
                var k = Math.floor(rnd() * (j + 1));
                var tmp = pool[j]; pool[j] = pool[k]; pool[k] = tmp;
            }
            // Direkte Wiederholung ueber die Beutel-Grenze vermeiden.
            if (avoidRepeat && count > 1 && pool[0] === last) {
                var swapWith = 1 + Math.floor(rnd() * (pool.length - 1));
                var t2 = pool[0]; pool[0] = pool[swapWith]; pool[swapWith] = t2;
            }
        }

        return {
            next: function () {
                if (!pool.length) refill();
                last = pool.shift();
                return last;
            }
        };
    }

    function pickSourceIn(src, durSec, mode, rnd, fps) {
        var avail = src.srcOut - src.srcIn;
        var slack = avail - durSec;

        // Spaetester In-Punkt, bei dem die volle Dauer noch im Clip liegt.
        var maxIn = Math.floor((src.srcOut - durSec) * fps) / fps;
        function clamp(v) {
            if (v < src.srcIn) return src.srcIn;
            if (v > maxIn) return maxIn < src.srcIn ? src.srcIn : maxIn;
            return v;
        }

        if (mode === 'start' || slack <= 0) return src.srcIn;

        if (mode === 'progressive') {
            if (src.pos + durSec > src.srcOut) src.pos = src.srcIn;
            var p = clamp(snap(src.pos, fps));
            src.pos = snap(p + durSec, fps);
            return p;
        }
        return clamp(snap(src.srcIn + rnd() * slack, fps));   // 'random'
    }

    /*
     * Baut die Schnittliste: pro Beat-Segment ein (oder bei zu kurzem Material
     * mehrere) Clips, luecklos aneinander.
     */
    function buildPlan(cuts, sources, cfg, fps, rnd) {
        var frame = 1 / fps;
        var bag = makeBag(sources.length, rnd, cfg.avoidRepeat);
        var plan = [];
        var warnings = 0;
        var gaps = 0;

        for (var c = 0; c < cuts.length - 1; c++) {
            var segStart = snap(cuts[c] + cfg.startOffset, fps);
            var segEnd = snap(cuts[c + 1] + cfg.startOffset, fps);
            if (segEnd <= segStart) continue;

            var t = segStart;
            var guard = 0;
            while (segEnd - t > frame / 2 && guard < 64) {
                guard++;
                var remaining = segEnd - t;

                // Clip suchen, der lang genug ist (max. sources.length Versuche).
                var idx = bag.next();
                var tries = 0;
                while (tries < sources.length &&
                       (sources[idx].srcOut - sources[idx].srcIn) < remaining - frame / 2) {
                    idx = bag.next();
                    tries++;
                }

                var src = sources[idx];
                var avail = src.srcOut - src.srcIn;
                var dur = Math.min(remaining, avail);

                // Keine Ein-Frame-Reste am Segmentende stehen lassen.
                var leftover = remaining - dur;
                if (leftover > 0 && leftover < cfg.minShotFrames * frame) {
                    var reduced = dur - (cfg.minShotFrames * frame - leftover);
                    if (reduced >= cfg.minShotFrames * frame) dur = reduced;
                }
                dur = snap(dur, fps);
                if (dur < frame) dur = frame;
                if (dur < remaining - frame / 2) warnings++;

                var srcIn = pickSourceIn(src, dur, cfg.inPointMode, rnd, fps);
                // Bleed: ein Frame mehr Quellmaterial, damit der naechste
                // Overwrite sauber drueberschneidet statt eine Luecke zu lassen.
                var srcOut = Math.min(src.srcOut, snap(srcIn + dur + cfg.bleedFrames * frame, fps));
                if (srcOut <= srcIn) srcOut = Math.min(src.srcOut, srcIn + frame);

                plan.push({
                    start: t,
                    end: snap(t + dur, fps),
                    sourceIndex: idx,
                    name: src.name,
                    srcIn: srcIn,
                    srcOut: srcOut
                });

                t = snap(t + dur, fps);
            }
            if (segEnd - t > frame / 2) gaps++;
        }
        return { plan: plan, shortSegments: warnings, gaps: gaps };
    }

    // ----------------------------------------------------------- placement

    function setPoints(projectItem, inSec, outSec) {
        var types = [MEDIA_TYPE_ANY, MEDIA_TYPE_VIDEO];
        for (var i = 0; i < types.length; i++) {
            try {
                projectItem.setInPoint(inSec, types[i]);
                projectItem.setOutPoint(outSec, types[i]);
                return true;
            } catch (e) { /* naechster Typ */ }
        }
        try {
            projectItem.setInPoint(toTime(inSec), MEDIA_TYPE_ANY);
            projectItem.setOutPoint(toTime(outSec), MEDIA_TYPE_ANY);
            return true;
        } catch (e2) {
            return false;
        }
    }

    function overwriteAt(track, projectItem, sec) {
        try {
            track.overwriteClip(projectItem, sec);
            return true;
        } catch (e) {
            try {
                track.overwriteClip(projectItem, toTime(sec));
                return true;
            } catch (e2) {
                log('Overwrite fehlgeschlagen bei ' + round2(sec) + 's: ' + e2.toString());
                return false;
            }
        }
    }

    function clearTrack(track) {
        var removed = 0;
        for (var i = track.clips.numItems - 1; i >= 0; i--) {
            try { track.clips[i].remove(false, false); removed++; } catch (e) { /* weiter */ }
        }
        return removed;
    }

    function snapshotPoints(sources) {
        var seen = [];
        var saved = [];
        for (var i = 0; i < sources.length; i++) {
            var pi = sources[i].projectItem;
            if (indexOf(seen, pi.nodeId) >= 0) continue;
            seen.push(pi.nodeId);
            try {
                saved.push({
                    item: pi,
                    inSec: pi.getInPoint(MEDIA_TYPE_ANY).seconds,
                    outSec: pi.getOutPoint(MEDIA_TYPE_ANY).seconds
                });
            } catch (e) { /* nicht wiederherstellbar */ }
        }
        return saved;
    }

    function restorePoints(saved) {
        for (var i = 0; i < saved.length; i++) {
            try { setPoints(saved[i].item, saved[i].inSec, saved[i].outSec); } catch (e) { /* egal */ }
        }
    }

    function muteAudioTracks(seq, before) {
        var muted = 0;
        for (var i = 0; i < seq.audioTracks.numTracks; i++) {
            var track = seq.audioTracks[i];
            if (track.clips.numItems > (before[i] || 0)) {
                try { track.setMute(1); muted++; } catch (e) { /* egal */ }
            }
        }
        return muted;
    }

    function audioClipCounts(seq) {
        var counts = [];
        for (var i = 0; i < seq.audioTracks.numTracks; i++) counts.push(seq.audioTracks[i].clips.numItems);
        return counts;
    }

    // ---------------------------------------------------------------- main

    function run(options) {
        LOG = [];
        var cfg = {};
        for (var key in DEFAULTS) { if (has(DEFAULTS, key)) cfg[key] = pick(options, key); }

        cfg.sourceTrack = parseInt(cfg.sourceTrack, 10);
        cfg.targetTrack = parseInt(cfg.targetTrack, 10);
        cfg.firstBeat = parseInt(cfg.firstBeat, 10) || 0;
        cfg.maxCuts = parseInt(cfg.maxCuts, 10) || 0;
        cfg.bpm = parseFloat(cfg.bpm);
        cfg.bpmOffset = parseFloat(cfg.bpmOffset) || 0;
        cfg.gridLength = parseFloat(cfg.gridLength) || 180;
        cfg.startOffset = parseFloat(cfg.startOffset) || 0;
        cfg.minShotFrames = parseInt(cfg.minShotFrames, 10) || 2;
        cfg.bleedFrames = parseInt(cfg.bleedFrames, 10);
        if (isNaN(cfg.bleedFrames)) cfg.bleedFrames = 1;

        var seq = getSequence();
        var fps = getFps(seq);

        // 1) Beat-Raster
        var grid;
        if (cfg.beatSource === 'markers') grid = beatsFromMarkers(seq);
        else if (cfg.beatSource === 'bpm') grid = beatsFromBpm(cfg.bpm, cfg.bpmOffset, cfg.gridLength);
        else grid = beatsFromFile(cfg.beatsFile);

        // 2) Musik-Offset. Marker liegen schon in Sequenzzeit -> kein Offset.
        if (cfg.beatSource === 'markers') {
            cfg.startOffset = 0;
        } else if (cfg.autoOffset) {
            var hint = grid.meta && grid.meta.file ? stripExt(basename(grid.meta.file)) : '';
            cfg.startOffset = snap(detectMusicOffset(seq, hint), fps);
        }

        // 3) Schnittpunkte
        var pattern = parsePattern(cfg.pattern);
        var cuts = buildCutPoints(grid.beats, pattern, cfg.firstBeat, cfg.maxCuts);
        if (cuts.length < 2) throw new Error('Zu wenige Beats fuer einen Schnitt (' + cuts.length + ').');

        // 4) Quellclips
        var sources = (cfg.sourceMode === 'bin')
            ? sourcesFromBin(cfg.sourceBin)
            : sourcesFromTrack(seq, cfg.sourceTrack);

        // 5) Plan bauen (vor jeder Aenderung an der Sequenz)
        var rnd = makeRandom(parseInt(cfg.seed, 10) || 0);
        var built = buildPlan(cuts, sources, cfg, fps, rnd);
        var plan = built.plan;
        if (!plan.length) throw new Error('Es konnte kein Schnitt geplant werden.');

        // 6) Zielspur vorbereiten
        var target = getVideoTrack(seq, cfg.targetTrack, 'Zielspur');
        if (cfg.clearTarget) clearTrack(target);

        // 7) Platzieren
        var saved = snapshotPoints(sources);
        var audioBefore = audioClipCounts(seq);
        var placed = 0, failed = 0;

        for (var i = 0; i < plan.length; i++) {
            var step = plan[i];
            var pi = sources[step.sourceIndex].projectItem;
            if (!setPoints(pi, step.srcIn, step.srcOut)) { failed++; continue; }
            if (overwriteAt(target, pi, step.start)) placed++; else failed++;
        }

        restorePoints(saved);

        var muted = 0;
        if (cfg.muteTargetAudio) muted = muteAudioTracks(seq, audioBefore);

        var lastCut = cuts[cuts.length - 1] + cfg.startOffset;
        var result = {
            ok: true,
            placed: placed,
            failed: failed,
            cuts: plan.length,
            beats: grid.beats.length,
            sources: sources.length,
            fps: Math.round(fps * 1000) / 1000,
            offset: round2(cfg.startOffset),
            pattern: pattern.join(','),
            length: round2(lastCut - (cuts[0] + cfg.startOffset)),
            endTimecode: timecode(lastCut, fps),
            shortSegments: built.shortSegments,
            gaps: built.gaps,
            mutedTracks: muted,
            log: LOG.join(' | ')
        };
        return result;
    }

    function stringify(res) {
        var out = [];
        for (var k in res) {
            if (!has(res, k)) continue;
            var v = res[k];
            out.push('"' + jsonEscape(k) + '":' +
                     (typeof v === 'number' || typeof v === 'boolean' ? String(v) : '"' + jsonEscape(v) + '"'));
        }
        return '{' + out.join(',') + '}';
    }

    function runFromJSON(jsonString) {
        try {
            return stringify(run(parseJSON(jsonString)));
        } catch (e) {
            return stringify({ ok: false, error: e.toString(), line: e.line || 0, log: LOG.join(' | ') });
        }
    }

    return {
        DEFAULTS: DEFAULTS,
        run: run,
        runFromJSON: runFromJSON,
        stringify: stringify,
        _internals: {
            parsePattern: parsePattern,
            buildCutPoints: buildCutPoints,
            buildPlan: buildPlan,
            makeRandom: makeRandom,
            parseJSON: parseJSON
        }
    };
})();
