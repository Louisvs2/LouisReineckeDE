#!/usr/bin/env bash
# Installiert das Clip-Beat-Randomizer-Panel fuer Adobe Premiere Pro (macOS).
#
#   ./install.sh            installieren
#   ./install.sh --link     statt kopieren einen Symlink setzen (zum Entwickeln)
#   ./install.sh --uninstall
set -euo pipefail

BUNDLE="com.clipbeatrandomizer.panel"
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)/extension/$BUNDLE"
DEST_DIR="$HOME/Library/Application Support/Adobe/CEP/extensions"
DEST="$DEST_DIR/$BUNDLE"

if [[ "$(uname)" != "Darwin" ]]; then
  echo "Dieses Skript ist fuer macOS. Unter Windows install.bat benutzen." >&2
  exit 1
fi

if [[ "${1:-}" == "--uninstall" ]]; then
  rm -rf "$DEST"
  echo "Entfernt: $DEST"
  exit 0
fi

if [[ ! -d "$SRC" ]]; then
  echo "Panel-Quelle nicht gefunden: $SRC" >&2
  exit 1
fi

# Unsignierte Extensions erlauben (sonst zeigt Premiere das Panel nicht an).
for v in 9 10 11 12 13; do
  defaults write "com.adobe.CSXS.$v" PlayerDebugMode 1 2>/dev/null || true
done
echo "PlayerDebugMode gesetzt (CSXS 9-13)."

mkdir -p "$DEST_DIR"
rm -rf "$DEST"

if [[ "${1:-}" == "--link" ]]; then
  ln -s "$SRC" "$DEST"
  echo "Symlink angelegt: $DEST -> $SRC"
else
  cp -R "$SRC" "$DEST"
  echo "Kopiert nach: $DEST"
fi

cat <<'MSG'

Fertig. Jetzt in Premiere Pro:
  Fenster -> Erweiterungen -> Clip Beat Randomizer

Falls das Panel nicht auftaucht: Premiere komplett beenden und neu starten.
MSG
