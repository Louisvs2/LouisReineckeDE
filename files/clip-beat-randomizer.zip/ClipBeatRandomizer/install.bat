@echo off
REM Installiert das Clip-Beat-Randomizer-Panel fuer Adobe Premiere Pro (Windows).
REM   install.bat              installieren
REM   install.bat --uninstall  entfernen
setlocal

set "BUNDLE=com.clipbeatrandomizer.panel"
set "SRC=%~dp0extension\%BUNDLE%"
set "DEST=%APPDATA%\Adobe\CEP\extensions\%BUNDLE%"

if "%~1"=="--uninstall" (
  if exist "%DEST%" rmdir /s /q "%DEST%"
  echo Entfernt: %DEST%
  goto :eof
)

if not exist "%SRC%" (
  echo Panel-Quelle nicht gefunden: %SRC%
  exit /b 1
)

REM Unsignierte Extensions erlauben, sonst blendet Premiere das Panel aus.
for %%V in (9 10 11 12 13) do (
  reg add "HKCU\Software\Adobe\CSXS.%%V" /v PlayerDebugMode /t REG_SZ /d 1 /f >nul 2>&1
)
echo PlayerDebugMode gesetzt (CSXS 9-13).

if exist "%DEST%" rmdir /s /q "%DEST%"
mkdir "%DEST%" >nul 2>&1
xcopy "%SRC%" "%DEST%" /E /I /Y >nul
echo Kopiert nach: %DEST%

echo.
echo Fertig. Jetzt in Premiere Pro:
echo   Fenster -^> Erweiterungen -^> Clip Beat Randomizer
echo.
echo Falls das Panel nicht auftaucht: Premiere komplett beenden und neu starten.
endlocal
