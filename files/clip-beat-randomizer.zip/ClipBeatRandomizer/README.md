# Clip Beat Randomizer

Ein andockbares CEP-Panel für **Adobe Premiere Pro**, das aus bereits
rausgeschnittenen Clips automatisch einen Beat-Edit baut: die Clips werden
gemischt und framegenau auf die Beats eines Songs geschnitten — Cut auf Cut,
auf Knopfdruck.

Autor: Louis Reinecke

## Inhalt

| Datei | Inhalt |
|-------|--------|
| `extension/com.clipbeatrandomizer.panel/` | Das Panel — Oberfläche plus Schnittlogik |
| `docs/ClipBeatRandomizer.pdf` | Anleitung für Endnutzer — Einrichten, Regler, Ausgangswerte, Fehlermeldungen. Zum Weitergeben und Ausdrucken. |
| `docs/anleitung.html` | Quelle der Anleitung; daraus wird die PDF gedruckt |
| `install.sh` / `install.bat` | Installer für macOS und Windows |
| `tools/beat_detect.py` | Optional: Song analysieren → `beats.json` |
| `README.md` | Diese Datei |

Alles als ZIP: auf GitHub **Code → Download ZIP**, oder direkt
`https://github.com/Louisvs2/clip-beat-randomizer/archive/refs/heads/claude/premiere-beat-sync-script-jxduvi.zip`

---

## Installation

| OS | Befehl |
|---|---|
| macOS | `./install.sh` im entpackten Ordner |
| Windows | Doppelklick auf `install.bat` |

Der Installer setzt den `PlayerDebugMode` (nötig, weil das Panel nicht bei Adobe
signiert ist) und kopiert die Extension nach:

| OS      | Pfad |
|---------|------|
| macOS   | `~/Library/Application Support/Adobe/CEP/extensions/` |
| Windows | `%APPDATA%\Adobe\CEP\extensions\` |

Danach Premiere Pro neu starten und das Panel über
**Fenster → Erweiterungen → Clip Beat Randomizer** öffnen.

> `./install.sh --link` setzt statt einer Kopie einen Symlink auf das
> Repository — praktisch beim Entwickeln. `--uninstall` entfernt die Extension
> wieder. Ohne Neustart taucht das Panel nicht im Menü auf.

---

## Benutzung

1. Sequenz vorbereiten: Clips hintereinander auf **V1**, Song auf einer
   Audiospur, **V2** leer.
2. Beats festlegen — `Cmd/Strg+Shift+A`, Song abspielen, im Takt auf **M** tippen.
3. Parameter im Panel einstellen.
4. **Auf Beats schneiden** klicken.

Die Zielspur wird vor jedem Durchlauf geleert, die Quellspur nie verändert.

### Fehlermeldungen

| Meldung | Ursache |
|---------|---------|
| `Keine aktive Sequenz.` | Die Timeline hat nicht den Fokus |
| `Die Sequenz hat keine Marker.` | Marker sitzen auf einem Clip statt in der Sequenz |
| `Zielspur V… existiert nicht.` | Sequenz hat weniger Videospuren als eingestellt |
| `Auf V… liegen keine nutzbaren Clips.` | Quellspur leer oder falsche Nummer |
| `Ungueltiges JSON` | `beats.json` ist beschädigt oder keine JSON-Datei |

---

## Parameter

### Beats

| Regler | Auswahl | Default | Bedeutung |
|--------|---------|---------|-----------|
| **Quelle** | beats.json / Marker / BPM | beats.json | Woher das Beat-Raster kommt. Marker sind selbst getippt, `beats.json` kommt aus der Analyse, BPM erzeugt ein gleichmäßiges Raster. |
| **Musik-Offset** | Auto / Sekunden | Auto | Ab welcher Sekunde der Song in der Sequenz liegt. Automatisch gilt der längste Audioclip. Bei Markern entfällt der Offset. |

### Schnitt-Rhythmus

| Regler | Bereich | Default | Bedeutung |
|--------|---------|---------|-----------|
| **Beats/Schnitt** | 1 – 4 oder Muster | 1 | Tempo des Edits. `1` = jeder Beat, `4` = jeder Takt, `4,4,2,2,1,1,1,1` = Build-up. |
| **Ab Beat Nr.** | 0 und mehr | 0 | Überspringt das Intro. |
| **Max. Cuts** | 0 – offen | 0 | Begrenzt die Länge; 0 = bis der Song aus ist. |

### Material

| Regler | Auswahl | Default | Bedeutung |
|--------|---------|---------|-----------|
| **Clips von** | Videospur / Bin | Videospur | Quelle des Materials. Bei „Videospur“ zählt der getrimmte Bereich jedes Clips. |
| **Quellspur / Zielspur** | V1 … Vn | V1 → V2 | Woher geholt, wohin geschnitten wird. |
| **Vorher leeren** | an / aus | an | Räumt die Zielspur vor jedem Durchlauf. |
| **Clip-Ton** | an / aus | an | Schaltet die Audiospuren stumm, auf denen der Originalton landet. |

### Zufall

| Regler | Auswahl | Default | Bedeutung |
|--------|---------|---------|-----------|
| **Startpunkt** | zufällig / Clip-Anfang / fortlaufend | zufällig | Welche Stelle eines Clips zu sehen ist. |
| **Reihenfolge** | an / aus | an | Verhindert denselben Clip zweimal direkt hintereinander. |
| **Seed** | 0 oder Zahl | 0 | 0 würfelt neu, eine feste Zahl gibt exakt denselben Edit wieder. |

---

## Wie es funktioniert

### `BeatRandomizer.run(options)`

* Liest das Beat-Raster — aus `beats.json`, aus `sequence.markers` oder aus BPM.
* Bestimmt den Musik-Offset (`start − inPoint` des längsten Audioclips) und
  rechnet die Beats in Sequenzzeit um. Bei Markern entfällt das, die liegen
  bereits in Sequenzzeit.
* Baut aus dem Muster die Schnittpunkte: `idx += pattern[k % pattern.length]`.
* Sammelt die Quellclips samt ihrem getrimmten Bereich (`inPoint`/`outPoint`
  der TrackItems) — der Rohschnitt auf V1 bleibt dabei unangetastet.
* Erzeugt den kompletten Schnittplan **vor** der ersten Änderung an der Sequenz,
  damit ein Fehler nicht eine halb geschriebene Timeline hinterlässt.
* Setzt pro Segment `projectItem.setInPoint/setOutPoint` und ruft
  `track.overwriteClip()` auf; danach werden die ursprünglichen In-/Out-Punkte
  der Projektclips wiederhergestellt.

### `buildPlan(cuts, sources, cfg, fps, rnd)`

* Mischt die Clips als Beutel (Fisher-Yates): jeder kommt dran, bevor sich einer
  wiederholt, und über die Beutelgrenze hinweg nie zweimal direkt hintereinander.
* Sucht pro Segment einen Clip, der lang genug ist. Findet sich keiner, wird das
  Segment mit dem nächsten Clip aufgefüllt statt eine Lücke zu lassen.
* Wählt den In-Punkt je nach Modus und klemmt ihn auf
  `floor((srcOut − dur) · fps) / fps`, damit die volle Dauer im Clip liegt.
* Snappt alle Zeiten auf Frames (`Math.round(sec · fps) / fps`) und gibt jedem
  Clip einen Frame Überstand (*bleed*), den der folgende Overwrite wieder
  wegschneidet — so entstehen keine Ein-Frame-Löcher.

Der Zufall läuft über einen seedbaren LCG (`makeRandom`), nicht über
`Math.random()`. Deshalb lässt sich jeder Edit über den Seed exakt wiederholen.

---

## UI-Aufbau

Das Panel ist eine CEP-Extension (HTML), das Theme baut es selbst — es bleibt
bewusst weiß, statt sich an Premieres dunkle Oberfläche anzupassen.
Gestaltung: schwarz auf weiß, Orange nur als Akzent (louisreinecke.de).

* `--label-w` – feste Spaltenbreite für die Versal-Labels, unter 370 px rutscht
  das Label über das Feld.
* `.rule` / `.hair` – 1-px-Trennlinien in Schwarz bzw. Grau.
* `section > h2` – fette Versal-Überschrift, darunter die schwarze Linie.
* `.row` – Versal-Label (grau) plus Steuerelemente, umbruchfähig.
* `button.primary` – flache orange Fläche, weiße Versalschrift, volle Breite.
* Fußzeile: Trennlinie und rechtsbündig `BY LOUIS REINECKE` in Grau, 10 px.
* `js/cep-lite.js` ersetzt Adobes `CSInterface.js` — nur `evalScript`,
  Extension-Pfad, Host-Version und Datei-Dialog.

Farbpalette: `#FFFFFF` (Hintergrund), `#000000` (Schrift und Linien),
`#FF3B00` (Akzent/Primärbutton), `#8A8A8A` (Nebentext), `#C9C9C9` (Haarlinien).
Typografie: ausschließlich die Systemschrift.

`jsx/BeatRandomizerUI.jsx` baut denselben Look als ScriptUI-Dialog, für den
Betrieb ohne Panel — mit denselben Helfern (`bg()`, `fg()`, `rule()`, `card()`,
`sectionTitle()`) und dem per `onDraw` gezeichneten orangen Button.

---

## Anpassen

Die Defaults stehen ganz oben in `jsx/BeatRandomizer.jsx`:

```js
var DEFAULTS = {
    beatSource:  'json',      // 'json' | 'markers' | 'bpm'
    pattern:     '1',         // Beats pro Schnitt, z.B. "2,2,1,1"
    sourceTrack: 1,           // Quellspur (1-basiert)
    targetTrack: 2,           // Zielspur
    inPointMode: 'random',    // 'start' | 'random' | 'progressive'
    seed:        0,           // 0 = jedes Mal neu
    bleedFrames: 1            // Frame Ueberstand gegen Ein-Frame-Luecken
};
```

Die Anleitung wird aus `docs/anleitung.html` gedruckt:

```bash
node tools/build-pdf.js      # -> docs/ClipBeatRandomizer.pdf
```

---

## Tests

Die Schnittlogik läuft gegen einen Nachbau der Premiere-API und lässt sich ohne
Premiere prüfen:

```bash
node tools/test/run-tests.js
```

Abgedeckt: Schnitte sitzen framegenau auf den Beats, die Timeline bleibt
lückenlos, der Seed ist reproduzierbar, kein Clip wiederholt sich direkt,
In-/Out-Punkte bleiben im getrimmten Bereich, Musik-Offset-Erkennung, Marker-
und BPM-Modus sowie die Fehlermeldungen.

---

## Kompatibilität

Getestet gegen die Premiere-Scripting-API in ExtendScript/ES3-Syntax. Das Panel
verwendet ausschließlich klassische APIs (`Sequence`, `TrackItem`,
`ProjectItem.setInPoint/setOutPoint`, `VideoTrack.overwriteClip`, `Time`) und
läuft laut Manifest ab Premiere Pro 14 (2020). CEP 9 bis 13.

Die automatische Beat-Erkennung (`tools/beat_detect.py`) braucht Python 3 und
librosa; ohne diese Pakete funktionieren Marker- und BPM-Modus unverändert.
