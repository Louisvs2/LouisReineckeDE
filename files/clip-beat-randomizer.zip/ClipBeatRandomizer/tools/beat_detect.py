#!/usr/bin/env python3
"""Beat-Erkennung fuer den Clip Beat Randomizer.

Analysiert einen Song und schreibt eine beats.json, die das Premiere-Script
einliest. Ohne Analyse geht es auch: mit --bpm wird ein Raster gerechnet,
dafuer braucht es keine externen Pakete.

Beispiele
---------
    python beat_detect.py song.wav
    python beat_detect.py song.mp3 -o beats.json --downbeats
    python beat_detect.py --bpm 128 --offset 0.31 --duration 210 -o beats.json
    python beat_detect.py song.wav --subdivide 2        # auch Achtel
    python beat_detect.py song.wav --tempo-multiplier 0.5   # halbes Tempo
"""

from __future__ import annotations

import argparse
import json
import os
import sys
from typing import List, Optional


def die(msg: str, code: int = 1) -> "None":
    print(f"Fehler: {msg}", file=sys.stderr)
    raise SystemExit(code)


# --------------------------------------------------------------------- grid


def grid_from_bpm(bpm: float, offset: float, duration: float) -> List[float]:
    """Gleichmaessiges Beat-Raster ohne Audioanalyse."""
    if bpm <= 0:
        die("--bpm muss groesser als 0 sein.")
    if duration <= 0:
        die("--duration muss groesser als 0 sein.")
    step = 60.0 / bpm
    beats, t = [], float(offset)
    while t <= offset + duration + 1e-9:
        beats.append(round(t, 6))
        t += step
    return beats


# ------------------------------------------------------------------ analyse


def detect(path: str, tightness: float, units: str) -> tuple:
    """Beats via librosa. Gibt (beats, bpm, duration) zurueck."""
    try:
        import librosa  # noqa: WPS433  (bewusst lazy: nur fuer die Analyse noetig)
        import numpy as np
    except ImportError:
        die(
            "librosa ist nicht installiert.\n"
            "  pip install -r tools/requirements.txt\n"
            "Alternative ohne Installation: --bpm 128 --duration 210"
        )

    if not os.path.isfile(path):
        die(f"Audiodatei nicht gefunden: {path}")

    print(f"Lade {os.path.basename(path)} ...", file=sys.stderr)
    y, sr = librosa.load(path, sr=None, mono=True)
    duration = float(librosa.get_duration(y=y, sr=sr))

    print("Suche Beats ...", file=sys.stderr)
    if units == "onset":
        # Onsets statt Beat-Grid: enger am Material, unregelmaessiger.
        frames = librosa.onset.onset_detect(y=y, sr=sr, backtrack=True)
        beats = librosa.frames_to_time(frames, sr=sr)
        tempo_arr = librosa.feature.tempo(y=y, sr=sr)
        bpm = float(np.atleast_1d(tempo_arr)[0])
    else:
        tempo, frames = librosa.beat.beat_track(y=y, sr=sr, tightness=tightness, units="frames")
        beats = librosa.frames_to_time(frames, sr=sr)
        bpm = float(np.atleast_1d(tempo)[0])

    return [round(float(b), 6) for b in beats], round(bpm, 2), round(duration, 3)


# ----------------------------------------------------------------- shaping


def apply_multiplier(beats: List[float], factor: float) -> List[float]:
    """0.5 = nur jeder zweite Beat, 2 = zusaetzliche Zwischenbeats."""
    if factor == 1 or not beats:
        return beats
    if factor < 1:
        step = int(round(1 / factor))
        if step < 1:
            die("--tempo-multiplier ist zu klein.")
        return beats[::step]

    step = int(round(factor))
    out: List[float] = []
    for i, b in enumerate(beats):
        out.append(b)
        if i + 1 < len(beats):
            gap = (beats[i + 1] - b) / step
            out.extend(round(b + gap * k, 6) for k in range(1, step))
    return out


def subdivide(beats: List[float], n: int) -> List[float]:
    return apply_multiplier(beats, float(n)) if n > 1 else beats


def shift(beats: List[float], amount: float) -> List[float]:
    if not amount:
        return beats
    return [round(b + amount, 6) for b in beats if b + amount >= 0]


def clip_range(beats: List[float], start: Optional[float], end: Optional[float]) -> List[float]:
    out = beats
    if start is not None:
        out = [b for b in out if b >= start]
    if end is not None:
        out = [b for b in out if b <= end]
    return out


def every_nth(beats: List[float], n: int, first: int = 0) -> List[float]:
    return beats[first::n] if n > 1 or first else beats


def downbeats_from(beats: List[float], per_bar: int, first: int) -> List[float]:
    return beats[first::per_bar] if per_bar > 1 else list(beats)


# -------------------------------------------------------------------- main


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        description="Erzeugt beats.json fuer den Clip Beat Randomizer.",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("audio", nargs="?", help="Songdatei (wav, mp3, m4a, flac ...)")
    p.add_argument("-o", "--output", default="beats.json", help="Zieldatei (Standard: beats.json)")

    g = p.add_argument_group("Ohne Analyse")
    g.add_argument("--bpm", type=float, help="festes Tempo statt Analyse")
    g.add_argument("--offset", type=float, default=0.0, help="Sekunden bis zum ersten Beat")
    g.add_argument("--duration", type=float, default=0.0, help="Laenge des Rasters in Sekunden")

    a = p.add_argument_group("Analyse")
    a.add_argument("--units", choices=["beats", "onset"], default="beats",
                   help="beats = gleichmaessiges Raster, onset = jeder Einsatz")
    a.add_argument("--tightness", type=float, default=100.0,
                   help="wie streng librosa am Tempo klebt (Standard 100)")

    s = p.add_argument_group("Nachbearbeitung")
    s.add_argument("--tempo-multiplier", type=float, default=1.0,
                   help="0.5 = halbes Tempo, 2 = doppeltes Tempo")
    s.add_argument("--subdivide", type=int, default=1, help="Beats n-fach unterteilen")
    s.add_argument("--every", type=int, default=1, help="nur jeden n-ten Beat behalten")
    s.add_argument("--first", type=int, default=0, help="ab welchem Beat gezaehlt wird")
    s.add_argument("--shift", type=float, default=0.0, help="alle Beats um x Sekunden verschieben")
    s.add_argument("--start", type=float, help="Beats vor dieser Sekunde verwerfen")
    s.add_argument("--end", type=float, help="Beats nach dieser Sekunde verwerfen")
    s.add_argument("--downbeats", action="store_true", help="zusaetzlich Taktanfaenge speichern")
    s.add_argument("--beats-per-bar", type=int, default=4, help="Beats pro Takt (Standard 4)")
    return p


def main(argv: Optional[List[str]] = None) -> int:
    args = build_parser().parse_args(argv)

    if args.bpm:
        duration = args.duration or 300.0
        beats = grid_from_bpm(args.bpm, args.offset, duration)
        bpm, source, name = args.bpm, "bpm-grid", args.audio or ""
    else:
        if not args.audio:
            die("Bitte eine Audiodatei angeben oder --bpm benutzen.")
        beats, bpm, duration = detect(args.audio, args.tightness, args.units)
        source, name = f"librosa:{args.units}", args.audio

    if not beats:
        die("Es wurden keine Beats gefunden.")

    beats = apply_multiplier(beats, args.tempo_multiplier)
    beats = subdivide(beats, args.subdivide)
    beats = shift(beats, args.shift)
    beats = clip_range(beats, args.start, args.end)
    beats = every_nth(beats, args.every, args.first)

    if not beats:
        die("Nach der Nachbearbeitung sind keine Beats uebrig.")

    payload = {
        "version": 1,
        "file": os.path.basename(name) if name else "",
        "source": source,
        "bpm": bpm,
        "duration": duration,
        "count": len(beats),
        "beats": beats,
    }
    if args.downbeats:
        payload["downbeats"] = downbeats_from(beats, args.beats_per_bar, 0)

    with open(args.output, "w", encoding="utf-8") as fh:
        json.dump(payload, fh, indent=1)

    span = beats[-1] - beats[0]
    print(
        f"{len(beats)} Beats geschrieben nach {args.output}\n"
        f"  Tempo   : {bpm} BPM\n"
        f"  1. Beat : {beats[0]:.3f} s\n"
        f"  Bereich : {span:.1f} s",
        file=sys.stderr,
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
