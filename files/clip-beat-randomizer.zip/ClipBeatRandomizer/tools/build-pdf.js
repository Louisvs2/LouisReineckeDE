/*
 * Druckt docs/anleitung.html nach docs/ClipBeatRandomizer.pdf.
 *
 *   node tools/build-pdf.js
 *
 * Braucht Playwright oder Puppeteer. Ist keins von beiden da:
 *   npm i -D playwright && npx playwright install chromium
 * Alternativ die HTML im Browser oeffnen und ueber "Drucken -> Als PDF sichern"
 * ausgeben (A4, Raender 18mm/20mm, Hintergrundgrafiken an).
 */
'use strict';
const path = require('path');
const fs = require('fs');

const ROOT = path.join(__dirname, '..');
const SRC = path.join(ROOT, 'docs', 'anleitung.html');
const OUT = path.join(ROOT, 'docs', 'ClipBeatRandomizer.pdf');

const PDF_OPTIONS = {
  path: OUT,
  format: 'A4',
  printBackground: true,
  margin: { top: '18mm', bottom: '18mm', left: '20mm', right: '20mm' }
};

function loadEngine() {
  for (const name of ['playwright', 'playwright-core', 'puppeteer']) {
    try {
      return { name, mod: require(name) };
    } catch (e) { /* naechster Kandidat */ }
  }
  return null;
}

async function main() {
  if (!fs.existsSync(SRC)) {
    console.error(`Quelle fehlt: ${SRC}`);
    process.exit(1);
  }

  const engine = loadEngine();
  if (!engine) {
    console.error(
      'Weder Playwright noch Puppeteer gefunden.\n' +
      '  npm i -D playwright && npx playwright install chromium\n' +
      'Oder docs/anleitung.html im Browser drucken (A4, 18mm/20mm, Hintergrund an).'
    );
    process.exit(1);
  }

  const browser = await (engine.name === 'puppeteer'
    ? engine.mod.launch()
    : engine.mod.chromium.launch());

  const page = await browser.newPage();
  await page.goto('file://' + SRC, { waitUntil: 'load' });
  if (page.emulateMedia) await page.emulateMedia(engine.name === 'puppeteer' ? 'print' : { media: 'print' });
  await new Promise((r) => setTimeout(r, 300));
  await page.pdf(PDF_OPTIONS);
  await browser.close();

  const kb = Math.round(fs.statSync(OUT).size / 1024);
  console.log(`${path.relative(ROOT, OUT)} geschrieben (${kb} KB, via ${engine.name})`);
}

main().catch((err) => { console.error(err); process.exit(1); });
