/*
 * Minimaler Nachbau der Premiere-ExtendScript-API, damit sich BeatRandomizer.jsx
 * ausserhalb von Premiere testen laesst (node tools/test/run-tests.js).
 */
'use strict';
const fs = require('fs');
const path = require('path');
const vm = require('vm');

const TICKS_PER_SECOND = 254016000000;

function list(items) {
  const arr = items.slice();
  Object.defineProperty(arr, 'numItems', { get: () => arr.length });
  Object.defineProperty(arr, 'numTracks', { get: () => arr.length });
  return arr;
}

function makeProjectItem(name, id, durationSec) {
  let inSec = 0;
  let outSec = durationSec;
  return {
    name,
    nodeId: String(id),
    type: 1,
    setInPoint(sec) { inSec = typeof sec === 'object' ? sec.seconds : sec; },
    setOutPoint(sec) { outSec = typeof sec === 'object' ? sec.seconds : sec; },
    getInPoint() { return { seconds: inSec }; },
    getOutPoint() { return { seconds: outSec }; },
    _points() { return { inSec, outSec }; }
  };
}

function makeTrackItem(projectItem, startSec, srcIn, srcOut, owner) {
  const item = {
    name: projectItem.name,
    projectItem,
    start: { seconds: startSec },
    end: { seconds: startSec + (srcOut - srcIn) },
    inPoint: { seconds: srcIn },
    outPoint: { seconds: srcOut },
    remove() {
      const i = owner.clips.indexOf(item);
      if (i >= 0) owner.clips.splice(i, 1);
    }
  };
  return item;
}

function makeVideoTrack(placements) {
  const track = {
    clips: list([]),
    overwriteClip(projectItem, time) {
      const sec = typeof time === 'object' ? time.seconds : time;
      const p = projectItem._points();
      placements.push({ name: projectItem.name, start: sec, srcIn: p.inSec, srcOut: p.outSec });
      const ti = makeTrackItem(projectItem, sec, p.inSec, p.outSec, track);
      track.clips.push(ti);
    }
  };
  return track;
}

function makeAudioTrack(clips) {
  const track = { clips: list(clips || []), muted: false, setMute(v) { track.muted = !!v; } };
  return track;
}

/**
 * @param {object} spec {fps, sources:[{name,dur,srcIn,srcOut}], videoTracks, music:{start,duration}}
 */
function buildSequence(spec) {
  const fps = spec.fps || 25;
  const placements = [];
  const projectItems = [];

  const sourceTrack = makeVideoTrack(placements);
  let cursor = 0;
  (spec.sources || []).forEach((s, i) => {
    const pi = makeProjectItem(s.name || `clip_${i + 1}`, i + 1, s.mediaDuration || s.dur + 10);
    projectItems.push(pi);
    const srcIn = s.srcIn === undefined ? 5 : s.srcIn;
    const srcOut = srcIn + s.dur;
    sourceTrack.clips.push(makeTrackItem(pi, cursor, srcIn, srcOut, sourceTrack));
    cursor += s.dur;
  });

  const videoTracks = [sourceTrack];
  for (let i = 1; i < (spec.videoTracks || 3); i++) videoTracks.push(makeVideoTrack(placements));

  const audioClips = [];
  if (spec.music) {
    const musicItem = makeProjectItem(spec.music.name || 'song.wav', 999, spec.music.duration);
    audioClips.push(makeTrackItem(musicItem, spec.music.start, spec.music.in || 0,
                                  (spec.music.in || 0) + spec.music.duration, { clips: [] }));
  }

  const markers = (spec.markers || []).map((sec) => ({ start: { seconds: sec } }));

  return {
    placements,
    projectItems,
    sequence: {
      timebase: String(Math.round(TICKS_PER_SECOND / fps)),
      videoTracks: list(videoTracks),
      audioTracks: list([makeAudioTrack(audioClips), makeAudioTrack([])]),
      markers: {
        numMarkers: markers.length,
        getFirstMarker: () => markers[0] || null,
        getNextMarker: (m) => markers[markers.indexOf(m) + 1] || null
      }
    }
  };
}

/** Laedt BeatRandomizer.jsx in eine Sandbox mit gestubbter Host-API. */
function loadScript(spec) {
  const built = buildSequence(spec);

  function Time() { this.seconds = 0; }

  const sandbox = {
    Time,
    ProjectItemType: { BIN: 2, CLIP: 1 },
    app: { project: { activeSequence: built.sequence, rootItem: { children: list([]) } } },
    File: function (p) {
      this.exists = fs.existsSync(p);
      this.encoding = 'UTF-8';
      this.open = () => this.exists;
      this.read = () => fs.readFileSync(p, 'utf8');
      this.close = () => true;
    },
    $: { global: {} },
    alert: () => {}
  };
  sandbox.window = sandbox;
  vm.createContext(sandbox);

  const src = fs.readFileSync(
    path.join(__dirname, '..', '..', 'extension', 'com.clipbeatrandomizer.panel', 'jsx', 'BeatRandomizer.jsx'),
    'utf8'
  );
  vm.runInContext(src, sandbox, { filename: 'BeatRandomizer.jsx' });

  return { BeatRandomizer: sandbox.BeatRandomizer, ...built };
}

module.exports = { loadScript, buildSequence, TICKS_PER_SECOND };
