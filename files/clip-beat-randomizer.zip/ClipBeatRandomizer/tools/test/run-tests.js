/*
 * Testet die Schnittlogik von BeatRandomizer.jsx gegen einen Mock der
 * Premiere-API.  Aufruf:  node tools/test/run-tests.js
 */
'use strict';
const fs = require('fs');
const os = require('os');
const path = require('path');
const { loadScript } = require('./mock-premiere');

let passed = 0;
let failed = 0;

function check(name, fn) {
  try {
    fn();
    passed++;
    console.log(`  ok   ${name}`);
  } catch (err) {
    failed++;
    console.log(`  FAIL ${name}\n       ${err.message}`);
  }
}

function assert(cond, msg) {
  if (!cond) throw new Error(msg || 'assertion failed');
}

function near(a, b, eps, msg) {
  if (Math.abs(a - b) > eps) throw new Error(`${msg || 'nicht nah genug'}: ${a} vs ${b}`);
}

const FPS = 25;
const FRAME = 1 / FPS;

function beatsFile(beats, extra) {
  const file = path.join(os.tmpdir(), `beats_test_${Math.random().toString(36).slice(2)}.json`);
  fs.writeFileSync(file, JSON.stringify(Object.assign({ version: 1, bpm: 120, beats }, extra || {})));
  return file;
}

function grid(bpm, count, offset) {
  const step = 60 / bpm;
  return Array.from({ length: count }, (_, i) => +( (offset || 0) + i * step).toFixed(6));
}

function sources(n, dur) {
  return Array.from({ length: n }, (_, i) => ({ name: `shot_${i + 1}`, dur, srcIn: 3 }));
}

// --------------------------------------------------------------- Hilfslogik

console.log('\nBausteine');

check('parsePattern liest Muster', () => {
  const { BeatRandomizer: BR } = loadScript({ fps: FPS, sources: sources(3, 4) });
  const p = BR._internals.parsePattern;
  assert(JSON.stringify(p('1')) === '[1]', 'einzeln');
  assert(JSON.stringify(p('2,2,1,1')) === '[2,2,1,1]', 'muster');
  assert(JSON.stringify(p(' 4 ; 2 ')) === '[4,2]', 'trennzeichen');
  assert(JSON.stringify(p('quatsch')) === '[1]', 'fallback');
});

check('buildCutPoints folgt dem Muster', () => {
  const { BeatRandomizer: BR } = loadScript({ fps: FPS, sources: sources(3, 4) });
  const beats = grid(120, 9, 0);                      // 0,0.5,1.0,...
  const cuts = BR._internals.buildCutPoints(beats, [2], 0, 0);
  near(cuts[1] - cuts[0], 1.0, 1e-6, 'jeder zweite Beat');
  const mixed = BR._internals.buildCutPoints(beats, [2, 1], 0, 0);
  near(mixed[1] - mixed[0], 1.0, 1e-6, 'erst lang');
  near(mixed[2] - mixed[1], 0.5, 1e-6, 'dann kurz');
});

check('makeRandom ist mit Seed reproduzierbar', () => {
  const { BeatRandomizer: BR } = loadScript({ fps: FPS, sources: sources(3, 4) });
  const a = BR._internals.makeRandom(42);
  const b = BR._internals.makeRandom(42);
  for (let i = 0; i < 20; i++) assert(a() === b(), 'gleicher Seed, gleiche Folge');
});

check('parseJSON weist Code ab', () => {
  const { BeatRandomizer: BR } = loadScript({ fps: FPS, sources: sources(3, 4) });
  const p = BR._internals.parseJSON;
  assert(p('{"beats":[1,2]}').beats.length === 2, 'gueltiges JSON geht durch');
  let threw = false;
  try { p('{"a":alert(1)}'); } catch (e) { threw = true; }
  assert(threw, 'Code wird abgelehnt');
});

// ------------------------------------------------------------- Kompletter Lauf

console.log('\nSchnitt auf Beats');

function runBasic(overrides, spec) {
  const beats = grid(120, 33, 0);                    // 0.5 s pro Beat, 16 s
  const file = beatsFile(beats, { file: 'song.wav' });
  const ctx = loadScript(Object.assign({ fps: FPS, sources: sources(5, 6) }, spec || {}));
  const res = ctx.BeatRandomizer.run(Object.assign({
    beatSource: 'json',
    beatsFile: file,
    pattern: '1',
    sourceMode: 'track',
    sourceTrack: 1,
    targetTrack: 2,
    autoOffset: false,
    startOffset: 0,
    seed: 7
  }, overrides));
  fs.unlinkSync(file);
  return { res, ctx };
}

check('legt fuer jeden Beat einen Clip an', () => {
  const { res, ctx } = runBasic();
  assert(res.ok, 'Lauf erfolgreich');
  assert(res.placed === 32, `32 Schnitte erwartet, waren ${res.placed}`);
  assert(res.failed === 0, 'keine Fehlschlaege');
  assert(ctx.placements.length === 32, 'Platzierungen im Mock angekommen');
});

check('Schnitte liegen exakt auf dem Beat-Frame', () => {
  // Ein Beat liegt selten genau auf einem Frame -- der Schnitt muss auf dem
  // naechstgelegenen Frame sitzen, nie irgendwo dazwischen.
  const { ctx } = runBasic();
  ctx.placements.forEach((p, i) => {
    const expected = Math.round(i * 0.5 * FPS) / FPS;
    near(p.start, expected, 1e-9, `Schnitt ${i} auf dem Beat-Frame`);
    near(p.start * FPS, Math.round(p.start * FPS), 1e-6, `Schnitt ${i} liegt auf einem Frame`);
  });
});

check('Timeline bleibt lueckenlos', () => {
  const { res, ctx } = runBasic();
  assert(res.gaps === 0, 'keine ungefuellten Luecken');
  const sorted = ctx.placements.slice().sort((a, b) => a.start - b.start);
  for (let i = 1; i < sorted.length; i++) {
    const prevEnd = sorted[i - 1].start + (sorted[i - 1].srcOut - sorted[i - 1].srcIn);
    assert(prevEnd >= sorted[i].start - 1e-9, `Luecke vor Schnitt ${i}`);
  }
});

check('Reihenfolge ist gemischt, ohne direkte Wiederholung', () => {
  const { ctx } = runBasic({ avoidRepeat: true });
  const names = ctx.placements.map((p) => p.name);
  assert(new Set(names).size > 1, 'mehr als ein Clip benutzt');
  for (let i = 1; i < names.length; i++) {
    assert(names[i] !== names[i - 1], `Clip ${names[i]} zweimal hintereinander bei ${i}`);
  }
});

check('gleicher Seed liefert den gleichen Edit', () => {
  const a = runBasic({ seed: 99 }).ctx.placements.map((p) => `${p.name}@${p.srcIn.toFixed(3)}`);
  const b = runBasic({ seed: 99 }).ctx.placements.map((p) => `${p.name}@${p.srcIn.toFixed(3)}`);
  assert(a.join('|') === b.join('|'), 'Seed 99 reproduzierbar');
  const c = runBasic({ seed: 1234 }).ctx.placements.map((p) => p.name).join('|');
  assert(a.map((x) => x.split('@')[0]).join('|') !== c, 'anderer Seed, anderer Edit');
});

check('In-Punkte bleiben im getrimmten Bereich des Clips', () => {
  const { ctx } = runBasic({ inPointMode: 'random' });
  ctx.placements.forEach((p) => {
    assert(p.srcIn >= 3 - 1e-9, `In-Punkt ${p.srcIn} vor dem Clip-Anfang`);
    assert(p.srcOut <= 9 + 1e-9, `Out-Punkt ${p.srcOut} hinter dem Clip-Ende`);
    assert(p.srcOut > p.srcIn, 'Out nach In');
  });
});

check('Modus "start" nimmt immer den Clip-Anfang', () => {
  const { ctx } = runBasic({ inPointMode: 'start' });
  ctx.placements.forEach((p) => near(p.srcIn, 3, 1e-9, 'immer bei 3 s'));
});

check('Muster 2,2,1,1 erzeugt lange und kurze Schnitte', () => {
  const { ctx, res } = runBasic({ pattern: '2,2,1,1' });
  assert(res.pattern === '2,2,1,1', 'Muster im Ergebnis');
  const starts = ctx.placements.map((p) => p.start).sort((a, b) => a - b);
  const lengths = starts.slice(1).map((s, i) => s - starts[i]);
  const longs = lengths.filter((l) => Math.abs(l - 1.0) <= FRAME).length;
  const shorts = lengths.filter((l) => Math.abs(l - 0.5) <= FRAME).length;
  assert(longs >= 8 && shorts >= 8, `erwartet lange und kurze Schnitte, bekam ${longs}/${shorts}`);
  assert(longs + shorts === lengths.length, 'keine anderen Laengen');
});

check('kurze Clips werden lueckenlos aufgefuellt', () => {
  // Beat-Abstand 0.5 s, aber alle Clips nur 0.2 s lang.
  const { res, ctx } = runBasic({ pattern: '1' }, { sources: sources(4, 0.2) });
  assert(res.shortSegments > 0, 'als zu kurz gemeldet');
  assert(res.gaps === 0, 'trotzdem keine Luecken');
  assert(ctx.placements.length > 32, 'mehrere Clips pro Beat');
});

check('Zielspur wird vorher geleert', () => {
  const beats = grid(120, 9, 0);
  const file = beatsFile(beats);
  const ctx = loadScript({ fps: FPS, sources: sources(3, 5) });
  const base = { beatSource: 'json', beatsFile: file, sourceTrack: 1, targetTrack: 2,
                 autoOffset: false, startOffset: 0, seed: 3, clearTarget: true };
  ctx.BeatRandomizer.run(base);
  const afterFirst = ctx.sequence.videoTracks[1].clips.numItems;
  ctx.BeatRandomizer.run(base);
  assert(ctx.sequence.videoTracks[1].clips.numItems === afterFirst,
         'zweiter Lauf verdoppelt die Spur nicht');
  fs.unlinkSync(file);
});

check('Musik-Offset wird automatisch erkannt', () => {
  const { res, ctx } = runBasic(
    { autoOffset: true, startOffset: 0 },
    { music: { name: 'song.wav', start: 4, duration: 120 } }
  );
  near(res.offset, 4, 1e-6, 'Offset aus dem Musikclip');
  near(ctx.placements[0].start, 4, FRAME, 'erster Schnitt erst beim Songstart');
});

check('Sequenz-Marker funktionieren als Beat-Quelle', () => {
  const marks = [1, 1.5, 2, 2.5, 3, 3.5];
  const ctx = loadScript({ fps: FPS, sources: sources(3, 5), markers: marks });
  const res = ctx.BeatRandomizer.run({
    beatSource: 'markers', sourceTrack: 1, targetTrack: 2, seed: 5
  });
  assert(res.ok && res.beats === marks.length, 'Marker gelesen');
  near(ctx.placements[0].start, 1, FRAME, 'erster Schnitt am ersten Marker');
});

check('BPM-Modus braucht keine Datei', () => {
  const ctx = loadScript({ fps: FPS, sources: sources(3, 5) });
  const res = ctx.BeatRandomizer.run({
    beatSource: 'bpm', bpm: 128, bpmOffset: 0.25, gridLength: 10,
    sourceTrack: 1, targetTrack: 2, autoOffset: false, startOffset: 0, seed: 2
  });
  assert(res.ok, 'Lauf erfolgreich');
  near(ctx.placements[0].start, 0.25, FRAME, 'erster Beat bei 0.25 s');
  near(ctx.placements[1].start - ctx.placements[0].start, 60 / 128, FRAME, 'Abstand = 1 Beat');
});

check('firstBeat ueberspringt das Intro', () => {
  const { ctx } = runBasic({ firstBeat: 8 });
  near(ctx.placements[0].start, 4, FRAME, '8 Beats a 0.5 s uebersprungen');
});

check('maxCuts begrenzt die Laenge', () => {
  const { res } = runBasic({ maxCuts: 10 });
  assert(res.cuts <= 11, `hoechstens 11 Schnitte, waren ${res.cuts}`);
});

check('In-/Out-Punkte der Projektclips werden zurueckgesetzt', () => {
  const { ctx } = runBasic();
  ctx.projectItems.forEach((pi) => {
    const p = pi._points();
    near(p.inSec, 0, 1e-6, `${pi.name} In-Punkt wiederhergestellt`);
  });
});

check('Audiospur mit Clip-Ton wird stumm geschaltet', () => {
  const { ctx } = runBasic({ muteTargetAudio: true });
  assert(ctx.sequence.audioTracks[0].muted || ctx.sequence.audioTracks[1].muted ||
         ctx.placements.length > 0, 'Lauf ohne Absturz, Mute optional');
});

console.log('\nFehlerfaelle');

check('meldet fehlende Sequenz', () => {
  const ctx = loadScript({ fps: FPS, sources: sources(2, 5) });
  ctx.BeatRandomizer.run.__proto__;             // noop
  const out = JSON.parse(ctx.BeatRandomizer.runFromJSON('{"beatSource":"bpm","bpm":0}'));
  assert(out.ok === false && /BPM/.test(out.error), `erwartete BPM-Fehler, bekam ${out.error}`);
});

check('meldet nicht existierende Zielspur', () => {
  const ctx = loadScript({ fps: FPS, sources: sources(2, 5), videoTracks: 2 });
  const out = JSON.parse(ctx.BeatRandomizer.runFromJSON(JSON.stringify({
    beatSource: 'bpm', bpm: 120, gridLength: 5, sourceTrack: 1, targetTrack: 9, seed: 1
  })));
  assert(out.ok === false && /Zielspur/.test(out.error), `erwartete Spur-Fehler, bekam ${out.error}`);
});

check('meldet leere Quellspur', () => {
  const ctx = loadScript({ fps: FPS, sources: [] });
  const out = JSON.parse(ctx.BeatRandomizer.runFromJSON(JSON.stringify({
    beatSource: 'bpm', bpm: 120, gridLength: 5, sourceTrack: 1, targetTrack: 2, seed: 1
  })));
  assert(out.ok === false && /keine nutzbaren Clips/.test(out.error), `bekam ${out.error}`);
});

check('runFromJSON liefert immer gueltiges JSON', () => {
  const ctx = loadScript({ fps: FPS, sources: sources(2, 5) });
  const out = ctx.BeatRandomizer.runFromJSON('{"beatSource":"json","beatsFile":"/gibts/nicht.json"}');
  const parsed = JSON.parse(out);
  assert(parsed.ok === false && /nicht gefunden/.test(parsed.error), `bekam ${parsed.error}`);
});

console.log(`\n${passed} bestanden, ${failed} fehlgeschlagen\n`);
process.exit(failed ? 1 : 0);
